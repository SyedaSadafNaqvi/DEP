<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  
<style> 
  footer{
    background-color: #4d0606;;
  }
  .footercont{
    width: 100%;
    padding: 30px 30px 10px;
  }
  .socialicons{
    color:#4d0606;
    display: flex;
    justify-content: center;
  }
  .socialicons a{
    text-decoration: none;
    padding: 10px;
    background-color: white;
    margin: 10px;
    border-radius: 50%;
}
.socialicons a i{
    color:#4d0606;
    font-size: 2em; 
    opacity: 0.9;
}
.socialicons a:hover{
    background-color: #4d0606;;
    transition: 0.5s;
}
.socialicons a:hover i{
    color: white;
    transition: 0.5s;
}
.footernav{
    margin: 20px 0;
}
.footernav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
}
.footernav ul li a{
    color: white;
    margin: 20px;
    text-decoration: none;
    font-size: 18px;
    opacity: 2;
    transition: 0.5s;
}
</style>
</div>
    <footer>
      <div class="footercont">
        <div class="socialicons">
          <a href=""><i class="fa-brands fa-facebook"></i></a>
          <a href=""><i class="fa-brands fa-instagram"></i></a>
          <a href=""><i class="fa-brands fa-twitter"></i></a>
          <a href=""><i class="fa-brands fa-pinterest"></i></a>
          <a href=""><i class="fa-brands fa-youtube"></i></a>
        </div>
        <div class="footernav">
          <ul>
            
            <li><a href="">About us</a></li>
            <li><a href="">Contact us</a></li>
            <li><a href="">Services</a></li>
            
          </ul>
        </div>
        <div class="footerbottom"></div>
      </div>
  
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html>
