<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
   
    <title>Blog</title>
</head>
<style>
    
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.navbar {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: white;
    padding: 20px;
    border-bottom: 2px solid  #cf2121;;
}

.navbar ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
}

.navbar li {
    margin: 0 15px;
    position: relative;
}

.navbar a {
    text-decoration: none;
    color:  #cf2121;;
    font-size: 16px;
    font-weight: bold;
    font-style: italic;
    padding: 5px;
    transition: color 0.3s ease;
}

.navbar a:hover {
    color:#4d0606; ;
    font-size: 1.02rem;
}

.navbar .logo {
    color: #cf2121;;
    font-family: 'San-serif', Arial;
    font-size: 40px;
    font-style: oblique;
    letter-spacing: 2px;
    margin: 0 50px;
    font-style: normal;
    position: relative;
}

.container {
    top: 10px;
    display: flex;
    margin: 0 auto;
    position: relative;
    align-items: center;
    justify-content: center;
    width: 90%;
    max-width: 900px;
    height: 600px;
}
.foreground-image {
    position: absolute;
    top: 50px; 
    left: 0;
    width: 100%;
    height: calc(100% - 30px); 
    background-image: url('img.jpeg');
    background-size: cover;
    background-position: center;
    z-index: 2; 
}

.background-box {
    position: absolute;
    bottom: 10px; 
    width: calc(100% + 20%); 
    height: calc(100% - 20%); 
    background-color:  #6d1212;; 
    z-index: 1; 
}
.post {
    margin-bottom: 20px;
}

.post h3 {
    margin: 0 0 10px;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    margin-top: 20px;
}

</style>
<body>
    <header>
    <nav class="navbar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Category</a></li>
            <li><a href="#">Archive</a></li>
        </ul>
        <div class="logo">MOONLIGHT</div>
        <ul>
            <li><a href="#">Elements</a></li>
            <li><a href="#">Blog Detail</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
    </header>
    <div class="container">
        <div class="background-box"></div>
        <div class="foreground-image"></div>
    </div>
    
<body>