<?php
include 'connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: index.php');
    exit;
} else {
    echo "ID NOT SPECIFIED";
}
?>
