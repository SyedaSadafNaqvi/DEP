
<?php include 'header.php'; ?>
<?php include 'connect.php'; ?>

<?php
if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $post = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE posts SET Title = ?, Content = ? WHERE id = ?");
    $stmt->execute([$_POST['Title'], $_POST['Content'], $_POST['id']]);
    header('Location: index.php');
}
?>

<div class="container">
    <h2>Edit Post</h2>
    <form action="post.php?id=<?php echo $post['id']; ?>" method="post">
        <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
        <label for="Title">Title:</label>
        <input type="text" id="Title" name="Title" value="<?php echo $post['Title']; ?>" required><br><br>
        <label for="Content">Content:</label>
        <textarea id="Content" name="Content" rows="10" required><?php echo $post['Content']; ?></textarea><br><br>
        <input type="submit" value="Update Post">
    </form>
</div>

<?php include 'footer.php'; ?>