<?php
include 'connect.php';
include 'header.php';
$post_id = '';
$title = '';
$content = '';
$form_action = 'Create a New Post';

if (isset($_GET['id']) && isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $post = $stmt->fetch();
    if ($post) {
        $post_id = $post['id'];
        $title = $post['Title'];
        $content = $post['Content'];
        $form_action = 'Edit Post';
    }
}

// Handle form submission for creating or editing a post
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    if (empty($id)) {
        // Insert a new post if no ID is set
        $stmt = $pdo->prepare("INSERT INTO posts (title, content) VALUES (?, ?)");
        $stmt->execute([$title, $content]);
    } else {
        // Update an existing post if ID is set
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ? WHERE id = ?");
        $stmt->execute([$title, $content, $id]);
    }

    // Redirect to avoid form resubmission on refresh
    header('Location: index.php');
    exit();
}

// Handle display of a single post based on the ID parameter
if (isset($_GET['id']) && !isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $post = $stmt->fetch();

    if ($post) {
        $title = htmlspecialchars($post['Title']);
        $content = htmlspecialchars($post['Content']);
        $display_post = true;
    } else {
        $display_post = false;
    }
} else {
    $display_post = false;
}
?>


<!-- Styling for the form and posts -->
<style>
    .containera {
        margin-top: 50px;
        margin-bottom: 100px;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 100vh;
        background-color: #f4f4f4;
    }

    .form-box {
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-width: 500px;
        width: 100%;
        margin-bottom: 40px;
    }

    .form-box h2 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    .form-box label {
        font-weight: bold;
        margin-bottom: 5px;
        display: block;
        color: #555;
    }

    .form-box input[type="text"],
    .form-box textarea {
        width: 98%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
        max-height: 150px; /* Adjust this value to decrease the height */
        overflow-y: auto;
    }

    .form-box input[type="submit"] {
        width: 100%;
        background-color: #cf2121;
        color: #fff;
        padding: 10px;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .form-box input[type="submit"]:hover {
        background-color: #a71a1a;
    }

    .post {
        background-color: #fff;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 8px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 600px;
    }

    .post h3 {
        margin-bottom: 10px;
    }

    .post a {
        color: #cf2121;
        text-decoration: none;
    }

    .post a:hover {
        text-decoration: underline;
    }
    .post .btn {
        background-color: #cf2121;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        font-size: 14px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-right: 10px;
        text-decoration: none;
    }

    .post .btn:hover {
        background-color: #a71a1a;
    }
    .h{
        margin-top: 70px;
        padding:30px;
        background: #6d1212;;
        margin-left:30px;
        margin-right:30px;
        border-radius: 15px;;
    }
    .h h2{
        color:white;
        font-family: 'San-serif', Arial;
        font-size: 40px;
        font-style: oblique;
        letter-spacing: 2px;
        margin: 0 80px;
    }
    .post-content {
        overflow: hidden;
        max-height: 100px;
        transition: max-height 0.3s ease;
    }

    .post-content.expanded {
        max-height: 2000px; 
    }
    .read-more-btn {
    background-color: #cf2121;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-right: 10px;
    text-decoration: none;
}

.read-more-btn:hover {
    background-color: #a71a1a;
}

</style>

</style>
<div class="h">
        <h2>All Posts</h2>
    </div>

    <div class="containera">
        <!-- Create or Edit Post Form -->
        <div class="form-box">
            <h2><?php echo $form_action; ?></h2>
            <form action="index.php" method="post">
                <input type="hidden" name="id" value="<?php echo $post_id; ?>">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>" required>

                <label for="content">Content:</label>
                <textarea id="content" name="content" rows="7" required><?php echo htmlspecialchars($content); ?></textarea>

                <input type="submit" value="<?php echo $form_action; ?>">
            </form>
        </div>

        <!-- Display Posts or Single Post Content -->
        <?php if ($display_post): ?>
            <div class="post-view">
                <h1><?php echo $title; ?></h1>
                <p><?php echo $content; ?></p>
                <a href="index.php" class="btn">Back to All Posts</a>
            </div>
        <?php else: ?>
            <!-- Display Posts List -->
            <?php
            try {
                $stmt = $pdo->query("SELECT * FROM posts ORDER BY created_at DESC");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $id = htmlspecialchars($row['id']);
                    $title = htmlspecialchars($row['Title']);
                    $content = htmlspecialchars(substr($row['Content'], 0, 100)) . '...';
                    
                    echo "<div class='post'>";
                    
                    echo "<h3><a href='index.php?id=$id'>$title</a></h3>";
                    echo "<p class='post-content' id='content-$id'>$content</p>";
                    echo "<button class='read-more-btn' data-target='content-$id'>Read More</button>";
                    echo "<a href='index.php?id=$id&edit=1' class='btn'>Edit</a>";
                    echo "<a href='delete.php?id=$id' onclick=\"return confirm('Are you sure you want to delete this post?');\" class='btn'>Delete</a>";
                    echo "</div>";
                }
            } catch (PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
            ?>
        <?php endif; ?>
    </div>

    <?php
    // Include the footer
    include 'footer.php';
    
    ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const buttons = document.querySelectorAll('.read-more-btn');

  console.log('Buttons found:', buttons.length);

  buttons.forEach(button => {
    button.addEventListener('click', function() {
      const targetId = this.getAttribute('data-target');
      const content = document.getElementById(targetId);

      console.log('Button clicked:', targetId, 'Content element:', content);

      if (content.classList.contains('expanded')) {
        content.classList.remove('expanded');
        this.textContent = 'Read More';
      } else {
        content.classList.add('expanded');
        this.textContent = 'Read Less';
      }

      console.log('Button clicked:', targetId, 'Content class:', content.classList);
    });
  });
});
</script>
    