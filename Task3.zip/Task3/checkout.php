<?php
session_start();
include 'db.php';
if (isset($_SESSION['message'])) {
    echo $_SESSION['message'];
    unset($_SESSION['message']);
}

// Fetch cart items from the session
$cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Calculate total quantity and price
$totalQuantity = 0;
$totalPrice = 0;
$products = [];

if ($cartItems) {
    foreach ($cartItems as $id => $quantity) {
        $query = "SELECT * FROM products WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['id' => $id]);
        $product = $stmt->fetch();
        if ($product) {
            $products[] = [
                'id' => $id,
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'image' => $product['image']
            ];
            $totalQuantity += $quantity;
            $totalPrice += $product['price'] * $quantity;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="checkout-container">
        <div class="cart-summary">
            <h2>List Product In Cart</h2>
            <?php foreach ($products as $product): ?>
            <div class="cart-item">
                <div class="item-details">
                    <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <span><?php echo htmlspecialchars($product['name']); ?></span>
                    <span><?php echo htmlspecialchars($product['quantity']); ?></span>
                    <span>$<?php echo htmlspecialchars($product['price']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="checkout-form">
            <h2>CHECKOUT</h2>
            <form action="process_checkout.php" method="POST">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required>

                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" required>

                <label for="address">Address</label>
                <input type="text" id="address" name="address" required>

                <label for="country">Country</label>
                <input type="text" id="country" name="country" required>

                <label for="city">City</label>
                <input type="text" id="city" name="city" required>

                <p class="total-info">Total Quantity: <span><?php echo $totalQuantity; ?></span></p>
                <p class="total-info">Total Price: <span>$<?php echo number_format($totalPrice, 2); ?></span></p>

                <button type="submit" class="checkout-button">CHECKOUT</button>
            </form>
            </form>
        </div>
    </div>
</body>
</html>
