<?php
include 'db.php';
session_start();

$query = "SELECT * FROM products";
$stmt = $pdo->prepare($query);
$stmt->execute();
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flower Shop</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>


<body>
    <header>
        <nav>
            <div class="logo">Flower Shop</div>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="#products">Shop</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
            <div class="cart-icon">
                <a href="#" id="cart-icon"><i class="fa fa-shopping-cart"></i></a>
            </div>
        </nav>

        <div id="cart-overlay" class="cart-overlay">
            <div class="cart-content">
                <div class="cart-header">
                    <h2>Shopping Cart</h2>
                    <span id="close-cart" class="close-cart">&times;</span>
                </div>
                <div class="cart-items">
                </div>
                <div class="cart-total">
                    <p>Subtotal: <span id="cart-subtotal">0</span></p>
                </div>
                <div class="cart-buttons">
                    <a href="checkout.php"><button class="checkout">CHECKOUT</button></a>
                </div>

            </div>
        </div>

        <div class="hero-section">
            <h3>Welcome to Florist</h3>
            <h1>Let's Make Beautiful Flowers a Part of Your Life.</h1>

            <a href="#products" class="cta-button">Shop Now</a>

        </div>
    </header>
    <section class="features">
        <div class="feature-box">
            <span class="feature-number">01</span>
            <h3>Order Online</h3>
            <p>Share some details here. This is a flexible section where you can share anything you want.</p>
        </div>
        <div class="feature-box">
            <span class="feature-number">02</span>
            <h3>Free Shipping</h3>
            <p>Share some details here. This is a flexible section where you can share anything you want.</p>
        </div>
        <div class="feature-box">
            <span class="feature-number">03</span>
            <h3>More Freshness</h3>
            <p>Share some details here. This is a flexible section where you can share anything you want.</p>
        </div>
        <div class="feature-box">
            <span class="feature-number">04</span>
            <h3>Safe Payment</h3>
            <p>Share some details here. This is a flexible section where you can share anything you want.</p>
        </div>
    </section>

    <div id="products" class="ab">
        <h3>NEW ARRIVAL</h3>
        <h1>Discover the Latest Additions at Your Top Choice Flower Shop</h1>
    </div>

    <div class="product-grid">
        <?php foreach ($products as $product): ?>
            <div class="product-item">
                <div class="product-image" style="position: relative;">
                    <img src="images/<?php echo htmlspecialchars($product['image']); ?>"
                        alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <div class="product-hover">
                        <span class="added-text">Added to Cart</span>
                        <a href="#" class="add-to-cart" data-id="<?php echo $product['id']; ?>">
                            <i class="fas fa-shopping-cart"></i>
                        </a>
                    </div>
                </div>
                <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                <p class="product-price">
                    <span class="price"><?php echo htmlspecialchars($product['price']); ?></span>
                </p>
            </div>
        <?php endforeach; ?>
    </div>
    <footer>
        <div class="footer-container">
            <div class="footer-section about">
                <h3>Flower Shop</h3>
                <p>Welcome to the world of Florist, where flowers come to life with love and creativity. Discover our
                    story, our passion for flowers, and our commitment to making every moment memorable.</p>
            </div>
            <div class="footer-section links">
                <h3>Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#products">Shop</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section contact">
                <h3>Contact Us</h3>
                <p>Address: 13 Fifth Avenue, Islamabad 101660</p>
                <p>Email: contact@info.com</p>
                <p>Phone: +923 0000000</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2024 Flower Shop</p>
            <div class="footer-social-icons">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </footer>


</body>

</html>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        function loadCart() {
            $.ajax({
                url: 'cart.php',
                type: 'GET',
                data: { action: 'fetch' },
                success: function (response) {
                    var data = JSON.parse(response);
                    var cartItems = data.cartItems;
                    var $cartItemsContainer = $('.cart-items');
                    $cartItemsContainer.empty();
                    cartItems.forEach(function (item) {
                        $cartItemsContainer.append(`
                        <div class="cart-item" data-id="${item.id}">
                            <img src="images/${item.image}" alt="${item.name}">
                            <div class="cart-item-details">
                                <h3>${item.name}</h3>
                                <p>Price: $${item.price}</p>
                                <div class="cart-item-controls">
                                    <button class="quantity-minus">-</button>
                                    <input type="text" class="quantity-input" value="${item.quantity}" readonly>
                                    <button class="quantity-plus">+</button>
                                    <button class="remove-item">&times;</button>

                                </div>
                            </div>
                        </div>
                    `);
                    });

                    // Update subtotal
                    var subtotal = cartItems.reduce(function (total, item) {
                        return total + (item.price * item.quantity);
                    }, 0);
                    $('#cart-subtotal').text(`$${subtotal.toFixed(2)}`);
                },
                error: function (xhr, status, error) {
                    console.error("Error occurred: " + error);
                }
            });
        }

        $('#cart-icon').on('click', function (e) {
            e.preventDefault();
            loadCart();
            $('#cart-overlay').fadeIn();
        });

        $('#close-cart').on('click', function () {
            $('#cart-overlay').fadeOut();
        });

        $('.add-to-cart').on('click', function (e) {
            e.preventDefault();
            var $this = $(this);

            $.ajax({
                url: 'cart.php',
                type: 'GET',
                data: { action: 'add', id: $this.data('id') },
                success: function (response) {
                    loadCart();
                    $this.siblings('.added-text').fadeIn().delay(2000).fadeOut();
                },
                error: function (xhr, status, error) {
                    console.error("Error occurred: " + error);
                }
            });
        });

        $(document).on('click', '.quantity-plus, .quantity-minus', function () {
            var $cartItem = $(this).closest('.cart-item');
            var itemId = $cartItem.data('id');
            var $quantityInput = $cartItem.find('.quantity-input');
            var currentQuantity = parseInt($quantityInput.val());

            if ($(this).hasClass('quantity-plus')) {
                currentQuantity++;
            } else if ($(this).hasClass('quantity-minus') && currentQuantity > 1) {
                currentQuantity--;
            }

            $quantityInput.val(currentQuantity);

            $.ajax({
                url: 'cart.php',
                type: 'POST',
                data: { action: 'update', id: itemId, quantity: currentQuantity },
                success: function (response) {
                    loadCart();
                },
                error: function (xhr, status, error) {
                    console.error("Error occurred: " + error);
                }
            });
        });

        $(document).on('click', '.remove-item', function () {
            var $cartItem = $(this).closest('.cart-item');
            var itemId = $cartItem.data('id');

            $.ajax({
                url: 'cart.php',
                type: 'POST',
                data: { action: 'remove', id: itemId },
                success: function (response) {
                    loadCart();
                },
                error: function (xhr, status, error) {
                    console.error("Error occurred: " + error);
                }
            });
        });
    });
</script>