<?php
include 'db.php';

$product_id = $_GET['id'];
$query = "SELECT * FROM products WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute(['id' => $product_id]);
$product = $stmt->fetch();

if (!$product) {
    die("Product not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Flower Shop</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Flower Shop</div>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
            <div class="cart-icon">
                <a href="cart.php"><i class="fa fa-shopping-cart"></i></a>
            </div>
        </nav>
    </header>
    
    <section class="product-detail">
        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
        <h1><?php echo htmlspecialchars($product['name']); ?></h1>
        <p><?php echo htmlspecialchars($product['description']); ?></p>
        <p>$<?php echo htmlspecialchars($product['price']); ?></p>
        <a href="cart.php?action=add&id=<?php echo htmlspecialchars($product['id']); ?>" class="btn">Add to Cart</a>
    </section>
</body>
</html>
