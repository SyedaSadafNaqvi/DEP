<?php
session_start();
include 'db.php';


if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty!";
    exit;
}


$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$country = $_POST['country'];
$city = $_POST['city'];


$totalPrice = 0;
foreach ($_SESSION['cart'] as $id => $quantity) {
    $query = "SELECT price FROM products WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $id]);
    $product = $stmt->fetch();
    if ($product) {
        $totalPrice += $product['price'] * $quantity;
    }
}


$query = "INSERT INTO orders (name, phone, address, country, city, total) VALUES (:name, :phone, :address, :country, :city, :totalPrice)";
$stmt = $pdo->prepare($query);
$stmt->execute([
    'name' => $name,
    'phone' => $phone,
    'address' => $address,
    'country' => $country,
    'city' => $city,
    'totalPrice' => $totalPrice
]);


$order_id = $pdo->lastInsertId();


foreach ($_SESSION['cart'] as $id => $quantity) {
    $query = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (:order_id, :product_id, :quantity)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        'order_id' => $order_id,
        'product_id' => $id,
        'quantity' => $quantity
    ]);
}


unset($_SESSION['cart']);


$_SESSION['message'] = "Thank you for your order! Your order has been placed successfully.";
header('Location: checkout.php');
exit;
?>
